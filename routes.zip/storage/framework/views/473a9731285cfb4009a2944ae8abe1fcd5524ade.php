<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alia Hospital</title>
    <link rel="stylesheet" href="css/jadwal.css">
</head>

<body>
    

    <?php $__env->startSection('content'); ?>

    <div class="search">
        <div class="form">
            <form>
                <input type="text" id="search-input" name="search-input" placeholder="Search...">
            </form>
        </div>
        <div class="hari">
            <h3>Hari</h3>
            <div class="jadwalHari">
                <label class="checkbox-container">
                    <input type="checkbox" />
                    <span class="checkbox-custom">Senin</span>
                </label>

                <label class="checkbox-container">
                    <input type="checkbox" />
                    <span class="checkbox-custom">Selasa</span>
                </label>
                <label class="checkbox-container">
                    <input type="checkbox" />
                    <span class="checkbox-custom">Rabu</span>
                </label>
                <label class="checkbox-container">
                    <input type="checkbox" />
                    <span class="checkbox-custom">Kamis</span>
                </label>
                <label class="checkbox-container">
                    <input type="checkbox" />
                    <span class="checkbox-custom">Jumat</span>
                </label>
                <label class="checkbox-container">
                    <input type="checkbox" />
                    <span class="checkbox-custom">Sabtu</span>
                </label>
                <label class="checkbox-container">
                    <input type="checkbox" />
                    <span class="checkbox-custom">Minggu</span>
                </label>
            </div>
        </div>

        <div class="spesialis">
            <h3>Spesialis/Poli</h3>
            <div class="bagian">
                <label class="checkbox-container">
                    <input type="checkbox" />
                    <span class="checkbox-custom">Anak</span>
                </label>
                <label class="checkbox-container">
                    <input type="checkbox" />
                    <span class="checkbox-custom">Bedah</span>
                </label>
                <label class="checkbox-container">
                    <input type="checkbox" />
                    <span class="checkbox-custom">Bedah Digestive</span>
                </label>
                <label class="checkbox-container">
                    <input type="checkbox" />
                    <span class="checkbox-custom">Fetomaternal</span>
                </label>
                <label class="checkbox-container">
                    <input type="checkbox" />
                    <span class="checkbox-custom">Fisik & Rehabilitasi</span>
                </label>
            </div>

            <div class="bagian">
                <label class="checkbox-container">
                    <input type="checkbox" />
                    <span class="checkbox-custom">Fisioterapi </span>
                </label>
                <label class="checkbox-container">
                    <input type="checkbox" />
                    <span class="checkbox-custom">Gigi</span>
                </label>
                <label class="checkbox-container">
                    <input type="checkbox" />
                    <span class="checkbox-custom">Jantung & Pembuluh Darah</span>
                </label>
                <label class="checkbox-container">
                    <input type="checkbox" />
                    <span class="checkbox-custom">Kulit & Kelamin</span>
                </label>
                <label class="checkbox-container">
                    <input type="checkbox" />
                    <span class="checkbox-custom">Mata</span>
                </label>

            </div>

            <div class="bagian">
                <label class="checkbox-container">
                    <input type="checkbox" />
                    <span class="checkbox-custom">Obgyn </span>
                </label>
                <label class="checkbox-container">
                    <input type="checkbox" />
                    <span class="checkbox-custom">Ortopedi</span>
                </label>
                <label class="checkbox-container">
                    <input type="checkbox" />
                    <span class="checkbox-custom">Paru</span>
                </label>
                <label class="checkbox-container">
                    <input type="checkbox" />
                    <span class="checkbox-custom">Penyakit Dalam</span>
                </label>
                <label class="checkbox-container">
                    <input type="checkbox" />
                    <span class="checkbox-custom">Saraf</span>
                </label>

            </div>

            <div class="bagian">
                <label class="checkbox-container">
                    <input type="checkbox" />
                    <span class="checkbox-custom">THT-KL </span>
                </label>
                <label class="checkbox-container">
                    <input type="checkbox" />
                    <span class="checkbox-custom">Tumbuh Kembang</span>
                </label>
                <label class="checkbox-container">
                    <input type="checkbox" />
                    <span class="checkbox-custom">Umum</span>
                </label>
                <label class="checkbox-container">
                    <input type="checkbox" />
                    <span class="checkbox-custom">Urologi</span>
                </label>
            </div>

        </div>
    </div>
    <div class="dokter">
    <?php $__currentLoopData = $dokter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dokter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card">
            <form action="/buatjanji2" method="POST">
                <?php echo csrf_field(); ?>
                <input type="text" name="dokter" id="dokter" value="<?php echo e($dokter->id); ?>" hidden>
                <div class="list-dokter">
                    <img src="images/<?php echo e($dokter->foto); ?>" alt="dokter">
                    <div class="kata">
                        <h2><?php echo e($dokter->namaDokter); ?></h2>
                        <h3><?php echo e($dokter->spesialis); ?></h3>
                        <ul>
                        <li><?php echo e($dokter->hari); ?> (<?php echo e($dokter->waktuAwal); ?> - <?php echo e($dokter->waktuAkhir); ?>)</li>
                        </ul>
                    </div>
                    </div>
                    <button type="submit">Buat Janji Temu</button>
            </form>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>




        <?php $__env->stopSection(); ?>



</body>

</html>

<?php echo $__env->make('Layout.app_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\alia-rs\resources\views/jadwal.blade.php ENDPATH**/ ?>