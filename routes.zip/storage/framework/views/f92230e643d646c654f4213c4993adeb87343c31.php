<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alia Hospital</title>
    <link rel="stylesheet" href="css/profil.css">
</head>

<body class="bg">
    

    <?php $__env->startSection('content'); ?>

    <div class="profil">
        <div class="profil-box">
            <h3><u>Data Saya</u></h3>
            <form action="/update-profile" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="text">
                    <div class="text-profil">
                        <div class="form">
                            <label for="nama">Nama Lengkap:</label>
                            <input type="text" id="nama" name="nama" value="<?php echo e($user->nama); ?>">
                        </div>
                        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <div class="form">
                            <label for="username">Username:</label>
                            <input type="text" id="username" name="username" value="<?php echo e($user->username); ?>">
                        </div>
                        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <div class="form">
                            <label for="tanggal_lahir">Tanggal Lahir:</label>
                            <input type="date" id="tanggal_lahir" name="tanggal_lahir" value="<?php echo e($user->tglLahir); ?>">
                        </div>
                        <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <div class="form">
                            <label for="whatsapp">No Whatsapp:</label>
                            <input type="text" id="whatsapp" name="whatsapp" value="<?php echo e($user->nomor); ?>">
                        </div>
                        <?php $__errorArgs = ['whatsapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <div class="form">
                            <label for="password">Buat Kata Sandi Baru:</label>
                            <input type="password" id="password" name="password" placeholder="Masukkan Kata Sandi Terbaru">
                        </div>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="img-con">
                        <img src=" <?php echo e($user->foto == null ? 'icons/user.svg' : '/images/'.$user->foto); ?>" alt="foto">
                        <div class="change-photo">
                            <label for="foto" class="btn">Upload Photo</label>
                            <input id="foto" name="foto" type="file" hidden>
                        </div>
                        <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <button type="submit">Update Profile</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="riwayat">
        <table class="riwayat-table">
            <thead>
                <tr>
                    <th colspan="5">Riwayat Janji Temu Dokter</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>No</td>
                    <td>Nama Dokter</td>
                    <td>Tanggal Kunjungan</td>
                    <td>Waktu Kunjungan</td>
                    <td>Status</td>
                </tr>
                <?php $__currentLoopData = $janji; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $janji): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="white-row">
                        <td><?php echo e($noJanji++); ?></td>
                        <td><?php echo e($janji->namaDokter); ?></td>
                        <td><?php echo e($janji->tglJanji); ?></td>
                        <td><?php echo e($janji->waktuJanji); ?></td>
                        <td>
                            <?php if($janji->status == "1"): ?>
                               Menunggu <a href="/batal/<?php echo e($janji->id); ?>" class="Batal">X</a>
                            <?php elseif($janji->status == "2"): ?>
                                Diterima
                            <?php elseif($janji->status == "0"): ?>
                                Ditolak <p class="infoJanji">i</p>
                                <p class="theInfo"><?php echo e($janji->alasan); ?></p>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- tambahkan baris sesuai dengan data yang ada -->
            </tbody>
        </table>
    </div>





    <?php $__env->stopSection(); ?>



</body>

</html>

<?php echo $__env->make('Layout.app_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\alia-rs\resources\views/profil.blade.php ENDPATH**/ ?>