<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin Alia Hospital</title>
    <link rel="stylesheet" href="/css/admindashboard.css">
    <script src="https://kit.fontawesome.com/88c065724b.js" crossorigin="anonymous"></script>
    <style>
        .content-1 {
            position: relative;
        }

        .form-pop {
            display: none;
            position: fixed;
            z-index: 999;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            backdrop-filter: blur(5px);
            max-width: 300px;
        }

        .form-pop::before {
            content: '';
            position: fixed;
            z-index: -1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .form-pop.visible {
            display: block;
        }

    </style>
</head>

<body>
    <a href="/logout"><img class="logout" src="images/logout.png" alt=""></a>
    <div class="content-1">
        <div class="title-1" style="text-align: center; text-decoration:underline">
            Permintaan Janji Temu Dokter</p>
        </div>
        <div class="table-1">
            <table>
                <tr>
                    <th class="kecil-1" style="border-top-left-radius:10px; border-bottom-left-radius:10px;">No</th>
                    <th class="besar-1">Nama Pasien</th>
                    <th class="kecil-1">WA</th>
                    <th class="besar-1">Nama Dokter</th>
                    <th class="besar-1">Tanggal & Waktu Kunjungan</th>
                    <th class="besar-1" style="border-top-right-radius:10px; border-bottom-right-radius:10px;">Status
                    </th>
                </tr>
                <?php $__currentLoopData = $janji; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $janji): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="kecil-1" style="border-top-left-radius:10px; border-bottom-left-radius:10px;">
                        <?php echo e($idjanji++); ?>

                    </td>
                    <td class="besar-1">
                        <a href="/profile/<?php echo e($janji->idPengguna); ?>"><?php echo e($janji->nama); ?></a>
                    </td>
                    <td class="kecil-1">
                        <a href="https://wa.me/<?php echo e($janji->nomor); ?>" target="_blank" class="logo-wa"><i
                                class="fa-brands fa-whatsapp"></i></a>
                    </td>
                    <td class="besar-1">
                        <?php echo e($janji->namaDokter); ?>

                    </td>
                    <td class="besar-1">
                        <?php echo e($janji->tglJanji); ?>, <?php echo e($janji->waktuJanji); ?>

                    </td>
                    <td class="besar-1"
                        style="border-top-right-radius:10px; border-bottom-right-radius:10px; position:relative;">
                        <?php if($janji->status == "1"): ?>
                        <span>
                            <a href="/approve/<?php echo e($janji->id); ?>" class="approve">Approve</a>
                        </span>
                        <span>
                            <button class="decline" onclick="openForm('myForm<?php echo e($janji->id); ?>')">Decline</button>
                        </span>
                        <?php elseif($janji->status == "2"): ?>
                        Approve
                        <?php elseif($janji->status == "0"): ?>
                        Decline
                        <?php endif; ?>
                        <div class="form-pop" id="myForm<?php echo e($janji->id); ?>">
                            <form action="/decline" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="text" name="id" value="<?php echo e($janji->id); ?>" hidden readonly>
                                <select name="alasan" id="alasan">
                                    <option selected disabled>Alasan</option>
                                    <option value="Dokter Berhalangan">Dokter Berhalangan</option>
                                    <option value="Hari Libur">Hari Libur</option>
                                </select>
                                <button type="submit">Decline</button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
    <div class="content-2">
        <div class="title-2">
            <span class="text-title-2">Jadwal Praktek Dokter</span>
            <span class="button-title-2"><a href="/addDokter">+</a></span>
        </div>
        <div class="table-2">
            <table>
                <tr>
                    <th class="kecil-2" style="border-top-left-radius:10px; border-bottom-left-radius:10px;">No</th>
                    <th class="besar-2">Nama Dokter</th>
                    <th class="kecil-2">Foto</th>
                    <th class="besar-2">Spesialis</th>
                    <th class="besar-2">Jadwal Praktek</th>
                    <th class="besar-2" style="border-top-right-radius:10px; border-bottom-right-radius:10px;">Action
                    </th>
                </tr>
                <?php $__currentLoopData = $dokter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dokter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="kecil-2" style="border-top-left-radius:10px; border-bottom-left-radius:10px;">
                        <?php echo e($idDokter++); ?>

                    </td>
                    <td class="besar-2">
                        <?php echo e($dokter->namaDokter); ?>

                    </td>
                    <td class="kecil-2">
                        <img src="/images/<?php echo e($dokter->foto); ?>" alt="Foto Dokter" style="width: 80px; height:80px">
                    </td>
                    <td class="besar-2">
                        <?php echo e($dokter->spesialis); ?>

                    </td>
                    <td class="besar-2">
                        <?php echo e($dokter->hari); ?>, <?php echo e($dokter->waktuAwal); ?> - <?php echo e($dokter->waktuAkhir); ?>

                    </td>
                    <td class="besar-2" style="border-top-right-radius:10px; border-bottom-right-radius:10px;">
                        <div>
                            <a href="/update/<?php echo e($dokter->id); ?>" class="update">Update</a>
                        </div>
                        <div style="margin-top: 20px">
                            <a href="/delete/<?php echo e($dokter->id); ?>" class="delete">Delete</a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
    <script>
        function openForm(formId) {
            document.getElementById(formId).classList.add("visible");
        }

    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\alia-rs\resources\views/AdminDashboard.blade.php ENDPATH**/ ?>