<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Alia Hospital</title>
    <link rel="stylesheet" href="css/lokasi.css">
</head>

<body class="page">
    

    <?php $__env->startSection('content'); ?>
    <div class="container-lokasi">
        <h1>ALIA HOSPITAL DEPOK</h1>
        <p>Jl. Kartini No.2, Kec. Pancoran Mas, Kota Depok </p>
        <img src="images/lokasi.png" alt="">
    </div>
    <?php $__env->stopSection(); ?>
</body>

</html>

<?php echo $__env->make('Layout.app_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\alia-rs\resources\views//lokasi.blade.php ENDPATH**/ ?>