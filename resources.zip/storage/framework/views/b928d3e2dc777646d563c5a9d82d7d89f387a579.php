

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="css/information.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="infoBase info3">
  <?php $__currentLoopData = range(0, 7); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="item">
    <div class="itemImage">
      <img class="imgFull" src="images/inap.jpeg" alt="">
    </div>
    <span>Info</span>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.app_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\alia-rs\resources\views/information3.blade.php ENDPATH**/ ?>