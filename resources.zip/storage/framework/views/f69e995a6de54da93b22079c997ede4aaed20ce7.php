<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Alia Hospital</title>
    <link rel="stylesheet" href="css/login.css">
    <style>
        @font-face {
            font-family: 'lilita';
            src: url('fonts/LilitaOne-Regular.ttf');
        }

        .text-decoration h1 {
            font-family: 'lilita', sans-serif;
        }
        .register-section a{
            text-decoration: none !important;
            color: black;
            padding: 8px 50px;
            background-color: white;
            border: 1px solid;
            border-radius: 15px;
            font-weight: 400;
        }
        .text-lupa-password a{
            text-decoration: none !important;
            color: black;
        }
    </style>
</head>
<body class="page">

    

    <?php $__env->startSection('content'); ?>
        <div class=".container">
            <form action="/login" method="POST" class="form">
                <?php echo csrf_field(); ?>
                <div class="login-contain">
                    <div class="text-masuk">
                        Masuk
                    </div>
                    <div class="input-data">
                        <div>
                            <input type="text" name="username" placeholder="Username">
                        </div>
                        <div>
                            <input type="password" name="password" placeholder="Kata Sandi">
                        </div>
                    </div>
                    <div class="text-lupa-password">
                        <a href="">forgot password?</a>
                    </div>
                    <div class="button">
                        <button type="submit">Masuk</button>
                    </div>
                </div>
        </div>
        <div class="text-decoration">
            <h1>SILAHKAN MASUK UNTUK BUAT JANJI TEMU DOKTER</h1>
        </div>
        <div class="register-section">
            <p>atau</p>
            <a href="/register">Daftar</a>
            <p>Jika belum memiliki akun</p>
        </div>
        <div class="login-image">
            <img src="/icons/loginImage.svg" alt="Dokter">
        </div>
    <?php $__env->stopSection(); ?>

</body>
</html>

<?php echo $__env->make('Layout.app_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\alia-rs\resources\views/login.blade.php ENDPATH**/ ?>