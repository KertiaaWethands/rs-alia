<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Alia Hospital</title>
    <link rel="stylesheet" href="css/paketkesehatan.css">
</head>

<body class="page">
    

    <?php $__env->startSection('content'); ?>
    <img src="images/payudara.png" alt="payudara">
    <?php $__env->stopSection(); ?>

</body>

</html>

<?php echo $__env->make('Layout.app_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\alia-rs\resources\views//PaketKesehatan/paketKesehatan2.blade.php ENDPATH**/ ?>