

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="css/information.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="infoBase info1">
  <img class="imgFull" src="images/inap.jpeg" alt="Rawat Inap">
  <div class="swiperBtn left">
    <i class="fa-solid fa-caret-left"></i>
  </div>
  <div class="swiperBtn right">
    <i class="fa-solid fa-caret-right"></i>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.app_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\alia-rs\resources\views/information1.blade.php ENDPATH**/ ?>