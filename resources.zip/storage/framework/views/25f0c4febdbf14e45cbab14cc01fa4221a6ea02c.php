<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Alia Hospital</title>
    <link rel="stylesheet" href="css/buatjanji.css">
</head>
<body>

    

    <?php $__env->startSection('content'); ?>
        <div class=".container">
            <form action="/buatjanji2" method="POST" class="form">
                <?php echo csrf_field(); ?>
                <div class="login-contain">
                    <div class="text-title">
                        Buat janji temu dokter
                    </div>
                    <div class="input-data">
                        <div class="option">
                            <select name="dokter" id="dokter">
                                <option selected disabled>Nama Dokter</option>
                                <?php $__currentLoopData = $dokter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dokter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($dokter->id); ?>"><?php echo e($dokter->namaDokter); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    <div class="button">
                        <button type="submit">Pilih Dokter</button>
                    </div>
                </div>
            </form>
        </div>
    <?php $__env->stopSection(); ?>

</body>
</html>

<?php echo $__env->make('Layout.app_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\alia-rs\resources\views/buatjanji1.blade.php ENDPATH**/ ?>