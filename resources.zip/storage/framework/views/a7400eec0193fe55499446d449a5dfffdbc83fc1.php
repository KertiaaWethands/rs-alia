<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Alia Hospital</title>
    <link rel="stylesheet" href="css/buatjanji.css">
</head>
<body>

    

    <?php $__env->startSection('content'); ?>
        <div class=".container">
            <form action="/buatjanji" method="POST" class="form" style="height: 400px">
                <?php echo csrf_field(); ?>   
                <div class="login-contain">
                    <div class="text-title">
                        Buat janji temu dokter
                    </div>
                    <div class="input-data">
                        <div hidden>
                            <input type="text" name="id" value="<?php echo e($dokter->id); ?>">
                        </div>
                        <div class="option">
                            <input type="text" name="nama" value="<?php echo e($dokter->namaDokter); ?>">
                        </div>
                        <div>
                            <input type="date" name="tglJanji" placeholder="Pilih Tanggal">
                        </div>
                        <div class="option">
                            <input type="text" name="waktuJanji" value="<?php echo e($dokter->waktuAwal); ?>" readonly>
                        </div>
                    </div>
                    <div class="button">
                        <button type="submit">Buat Janji</button>
                    </div>
                </div>
            </form>
        </div>
    <?php $__env->stopSection(); ?>

</body>
</html>

<?php echo $__env->make('Layout.app_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\alia-rs\resources\views/buatjanji2.blade.php ENDPATH**/ ?>